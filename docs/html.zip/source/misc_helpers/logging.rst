======================================
Helpers for Python's `logging` Library
======================================

`utilities/general.py``

Module Header and API Reference
-------------------------------

:ref:`kanji_time-utilities-general-py`

