:orphan:

.. _kanji_time-utilities-py-dev_notes:

=====================================
`utilities` Package Development Notes
=====================================

For: :mod:`visual.frame.utilities`

.. include:: /common


Future Feature Adds
-------------------

XML Utilities
~~~~~~~~~~~~~

    - Add some indent management to the :python:`utilities.xml.xml_tag` context manager - possibly by layering it around `StringIO`.


Code Review/Adjustments
-----------------------

    - nada!



