.. _visual-geometry-dev_guide:

Geometric Foundations
=====================


Module Header and API Reference
-------------------------------

Python module :mod:`visual.layout.region`

:ref:`kanji_time-visual-layout-region-py`


Details
-------

.. toctree::
   :maxdepth: 1

   distance
   pos
   extent
   region


