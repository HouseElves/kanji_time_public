:orphan:

.. _legal-notice:

Legal Notices
=============

.. include:: ../../NOTICE
