Model SVG Transforms as Stand-alone Instances
=============================================

svg_transform.py
----------------

**This file is misplaced:  the closest fit is in the adapters package.***

.. automodule:: kanji_time.svg_transform
   :members:
   :undoc-members:
   :member-order: bysource
   :show-inheritance:
