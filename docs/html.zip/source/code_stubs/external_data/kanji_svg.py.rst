.. _kanji_time-external_data-kanji_svg-py:

Recipes for Drawing Kanji with Vector Graphics
==============================================

external_data/kanji_svg.py
--------------------------

.. automodule:: kanji_time.external_data.kanji_svg
   :members:
   :undoc-members:
   :member-order: bysource
   :show-inheritance: