.. _kanji_time-external_data-kanji_dic2-py:

Comprehensive Information About Kanji as Stand-alone Units
==========================================================

external_data/kanji_dic2.py
---------------------------

.. automodule:: kanji_time.external_data.kanji_dic2
   :members:
   :undoc-members:
   :member-order: bysource
   :show-inheritance: