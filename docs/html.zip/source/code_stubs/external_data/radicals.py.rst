.. _kanji_time-external_data-radicals-py:

Canonical Kanji Radical Equivalences via Unicode
================================================

external_data/radicals.py
-------------------------

.. automodule:: kanji_time.external_data.radicals
   :members:
   :undoc-members:
   :member-order: bysource
   :show-inheritance: