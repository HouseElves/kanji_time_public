.. _kanji_time-external_data-settings-py:

Configuration Settings for External Data
========================================

external_data/settings.py
-------------------------

.. automodule:: kanji_time.external_data.settings
   :members:
   :undoc-members:
   :member-order: bysource
   :show-inheritance: