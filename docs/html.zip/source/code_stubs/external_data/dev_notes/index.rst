External Data Package `external_data` Notes
-------------------------------------------

.. toctree::
   :maxdepth: 2

   settings_notes
   kanji_svg_notes
   radicals_notes

