.. _kanji_time-external_data-_init_-py:

External Data Package
=====================

.. automodule:: kanji_time.external_data.__init__
   :members:
   :undoc-members:
   :member-order: bysource
   :show-inheritance: