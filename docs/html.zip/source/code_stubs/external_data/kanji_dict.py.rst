.. _kanji_time-external_data-kanji_dict-py:

Comprehensive Information about Multi-kanji Compounds as Words
==============================================================

external_data/kanji_dict.py
---------------------------

.. automodule:: kanji_time.external_data.kanji_dict
   :members:
   :undoc-members:
   :member-order: bysource
   :show-inheritance: