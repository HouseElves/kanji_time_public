.. include:: /common

Reports package `reports`
-------------------------

.. toctree::
   :maxdepth: 2

   controller_notes


|KT| Packaged Report Modules
----------------------------

    .. toctree::
       :maxdepth: 2

       ../kanji_summary/dev_notes/index
       ../practice_sheet/dev_notes/index
