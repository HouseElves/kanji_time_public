.. _kanji_time-reports-kanji_summary-_init_-py:

Kanji Summary Report
====================

.. automodule:: kanji_time.reports.kanji_summary.__init__
   :members:
   :undoc-members:
   :member-order: bysource
   :show-inheritance:
