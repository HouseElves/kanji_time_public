.. _kanji_time-reports-kanji_summary-report-py:

A Simple Report Controller Example: Kanji Summary
=================================================

reports/kanji_summary/report.py
-------------------------------

.. automodule:: kanji_time.reports.kanji_summary.report
   :members:
   :undoc-members:
   :member-order: bysource
   :show-inheritance:
