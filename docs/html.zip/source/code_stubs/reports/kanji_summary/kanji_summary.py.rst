.. _kanji_time-reports-kanji_summary-kanji_summary-py:

Present Dictionary Information About a Kanji
============================================

reports/kanji_summary/kanji_summary.py
--------------------------------------

.. automodule:: kanji_time.reports.kanji_summary.kanji_summary
   :members:
   :undoc-members:
   :member-order: bysource
   :show-inheritance:
