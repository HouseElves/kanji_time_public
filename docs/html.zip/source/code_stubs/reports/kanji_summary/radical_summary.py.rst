.. _kanji_time-reports-kanji_summary-radical_summary-py:

Custom Layout Frame Example: an Information Box
===============================================

reports/kanji_summary/radical_summary.py
----------------------------------------

.. automodule:: kanji_time.reports.kanji_summary.radical_summary
   :members:
   :undoc-members:
   :member-order: bysource
   :show-inheritance:
