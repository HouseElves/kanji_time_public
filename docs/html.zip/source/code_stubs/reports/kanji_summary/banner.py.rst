.. _kanji_time-reports-kanji_summary-banner-py:

Custom Layout Frame Example: a Page Banner
==========================================

reports/kanji_summary/banner.py
-------------------------------

.. automodule:: kanji_time.reports.kanji_summary.banner
   :members:
   :undoc-members:
   :member-order: bysource
   :show-inheritance:
