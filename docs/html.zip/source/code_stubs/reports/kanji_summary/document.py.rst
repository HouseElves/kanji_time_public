.. _kanji_time-reports-kanji_summary-document-py:

Represent Data for the Kanji Summary Independent of its Layout
==============================================================

reports/kanji_summary/document.py
---------------------------------

.. automodule:: kanji_time.reports.kanji_summary.document
   :members:
   :undoc-members:
   :member-order: bysource
   :show-inheritance:
