.. _kanji_time-reports-_init_-py:

Reports Package
===============

.. automodule:: kanji_time.reports.__init__
   :members:
   :undoc-members:
   :member-order: bysource
   :show-inheritance:
