.. _kanji_time-reports-controller-py:

Mediate Between Page Size Limits and Report Content
===================================================

reports/controller.py
---------------------

.. automodule:: kanji_time.reports.controller
   :members:
   :undoc-members:
   :member-order: bysource
   :show-inheritance:
