.. _kanji_time-reports-practice_sheet-report-py:

A Simple Report Controller Example: Practice Sheet
==================================================

reports/practice_sheet/report.py
--------------------------------

.. automodule:: kanji_time.reports.practice_sheet.report
   :members:
   :undoc-members:
   :member-order: bysource
   :show-inheritance:
