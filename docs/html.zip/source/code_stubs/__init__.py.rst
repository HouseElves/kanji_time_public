Project Root
============

**Defines the required global state for Kanji Time.**

.. automodule:: kanji_time.__init__
   :members:
   :undoc-members:
   :member-order: bysource
   :show-inheritance: