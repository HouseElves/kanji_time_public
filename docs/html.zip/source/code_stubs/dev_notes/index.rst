Root modules
------------

.. toctree::
   :maxdepth: 2

   settings_notes
   kanji_time_cli_notes
