.. _kanji_time-visual-frame-_init_-py:

==============
Content Frames
==============

.. automodule:: kanji_time.visual.frame.__init__
   :members:
   :undoc-members:
   :member-order: bysource
   :show-inheritance:
