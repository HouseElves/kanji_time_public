.. _kanji_time-visual-frame-page-py:

Manage Multi-page Reports
=========================

visual/frame/page.py
--------------------

.. automodule:: kanji_time.visual.frame.page
   :members:
   :undoc-members:
   :member-order: bysource
   :show-inheritance:
