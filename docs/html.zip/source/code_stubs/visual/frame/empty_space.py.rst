.. _kanji_time-visual-frame-empty_space-py:

Reserve Empty Space
===================

visual/frame/empty_space.py
---------------------------

.. automodule:: kanji_time.visual.frame.empty_space
   :members:
   :undoc-members:
   :member-order: bysource
   :show-inheritance:
