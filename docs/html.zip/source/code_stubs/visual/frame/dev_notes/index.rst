Rendering Frame Development Notes
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. toctree::
   :maxdepth: 2

   container_notes
   drawing_notes
   formatted_text_notes
   page_rule_notes
   empty_space_notes
