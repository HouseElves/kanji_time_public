.. _kanji_time-visual-frame-formatted_text-py:

Draw Text Content w/ Simple Markup Formatting
=============================================

visual/frame/formatted_text.py
------------------------------

.. automodule:: kanji_time.visual.frame.formatted_text
   :members:
   :undoc-members:
   :member-order: bysource
   :show-inheritance:
