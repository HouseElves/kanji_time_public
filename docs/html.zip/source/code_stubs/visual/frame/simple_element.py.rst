.. _kanji_time-visual-frame-simple_element-py:

Simple Frame Defaults for Atomic Content
========================================

visual/frame/simple_element.py
------------------------------

.. automodule:: kanji_time.visual.frame.simple_element
   :members:
   :undoc-members:
   :member-order: bysource
   :show-inheritance:
