.. _kanji_time-visual-frame-page_rule-py:

Draw a Horizontal Page Rule
===========================

visual/frame/page_rule.py
-------------------------

.. automodule:: kanji_time.visual.frame.page_rule
   :members:
   :undoc-members:
   :member-order: bysource
   :show-inheritance:
