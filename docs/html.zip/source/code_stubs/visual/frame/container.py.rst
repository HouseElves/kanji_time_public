.. _kanji_time-visual-frame-container-py:

Apply a Layout Strategy to Child Content
========================================

visual/frame/container.py
-------------------------

.. automodule:: kanji_time.visual.frame.container
   :members:
   :undoc-members:
   :member-order: bysource
   :show-inheritance:
