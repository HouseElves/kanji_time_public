.. _kanji_time-visual-protocol-layout_strategy-py:

Visual Entity Layout Strategy Protocol
======================================

visual/protocol/layout_strategy.py
----------------------------------

.. automodule:: kanji_time.visual.protocol.layout_strategy
   :members:
   :undoc-members:
   :member-order: bysource
   :show-inheritance:
