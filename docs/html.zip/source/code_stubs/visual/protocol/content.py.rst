.. _kanji_time-visual-protocol-content-py:

Visual Entity Content Protocol
==============================

visual/protocol/content.py
--------------------------

.. automodule:: kanji_time.visual.protocol.content
   :members:
   :undoc-members:
   :member-order: bysource
   :show-inheritance:
