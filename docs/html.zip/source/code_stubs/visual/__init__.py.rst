.. _kanji_time-visual-_init_-py:

Visual Package
==============

.. automodule:: kanji_time.visual.__init__
   :members:
   :undoc-members:
   :member-order: bysource
   :show-inheritance:
