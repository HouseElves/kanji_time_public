.. _kanji_time-visual-layout-_init_-py:

Visual Layout Control
=====================

.. automodule:: kanji_time.visual.layout.__init__
   :members:
   :undoc-members:
   :member-order: bysource
   :show-inheritance:
