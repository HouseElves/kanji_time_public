.. _kanji_time-visual-layout-anchor_point-py:

Position Frames Relative To Each Other
======================================

visual/layout/anchor_point.py
-----------------------------

.. automodule:: kanji_time.visual.layout.anchor_point
   :members:
   :undoc-members:
   :member-order: bysource
   :show-inheritance:
