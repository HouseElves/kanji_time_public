.. _kanji_time-visual-layout-distance-py:

Unit-Aware Immutable Distance Measure
=====================================

visual/layout/distance.py
-------------------------

.. automodule:: kanji_time.visual.layout.distance
   :members:
   :undoc-members:
   :member-order: bysource
   :show-inheritance:
