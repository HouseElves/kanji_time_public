Geometry package `visual.layout`
--------------------------------

.. toctree::
   :maxdepth: 2

   distance_notes
   region_notes


Layout Strategies
~~~~~~~~~~~~~~~~~

.. toctree::
   :maxdepth: 2

   stack_layout_notes

