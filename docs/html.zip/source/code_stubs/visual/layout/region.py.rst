.. _kanji_time-visual-layout-region-py:

Immutable Sizes & Areas w/ Optional Local Origin
================================================

visual/layout/region.py
-----------------------

.. automodule:: kanji_time.visual.layout.region
   :members:
   :undoc-members:
   :member-order: bysource
   :show-inheritance:
