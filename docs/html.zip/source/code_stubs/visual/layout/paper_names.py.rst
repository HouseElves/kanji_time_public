.. _kanji_time-visual-layout-paper_names-py:

Uniform Paper Sizes with ReportLab
==================================

visual/layout/paper_names.py
----------------------------

.. automodule:: kanji_time.visual.layout.paper_names
   :members:
   :undoc-members:
   :member-order: bysource
   :show-inheritance:
