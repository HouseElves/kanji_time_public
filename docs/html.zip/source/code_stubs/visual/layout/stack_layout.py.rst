.. _kanji_time-visual-layout-stack_layout-py:

Auto-layout Horizontal or Vertical Stacks
=========================================

visual/layout/stack_layout.py
-----------------------------

.. automodule:: kanji_time.visual.layout.stack_layout
   :members:
   :undoc-members:
   :member-order: bysource
   :show-inheritance:
