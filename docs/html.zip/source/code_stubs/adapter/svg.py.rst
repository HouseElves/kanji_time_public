.. _kanji_time-adapter-svg-py:

Make Variations in SVG Support Invisible
========================================

adapter/svg.py
--------------

.. automodule:: kanji_time.adapter.svg
   :members:
   :undoc-members:
   :member-order: bysource
   :show-inheritance: