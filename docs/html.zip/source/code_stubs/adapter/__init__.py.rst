:orphan:

.. _kanji_time-adapter-_init_-py:

Adapter Package
===============

.. automodule:: kanji_time.adapter.__init__
   :members:
   :undoc-members:
   :member-order: bysource
   :show-inheritance: