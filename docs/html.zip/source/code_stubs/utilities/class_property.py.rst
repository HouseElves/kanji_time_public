.. _kanji_time-utilities-class_property-py:

===========================
utilities/class_property.py
===========================

.. automodule:: kanji_time.utilities.class_property
   :members:
   :undoc-members:
   :member-order: bysource
   :show-inheritance:
