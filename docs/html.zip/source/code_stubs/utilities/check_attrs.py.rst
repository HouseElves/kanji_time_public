.. _kanji_time-utilities-check_attrs-py:

========================
utilities/check_attrs.py
========================

.. automodule:: kanji_time.utilities.check_attrs
   :members:
   :undoc-members:
   :member-order: bysource
   :show-inheritance:
