.. _kanji_time-utilities-xml-py:

================
utilities/xml.py
================

.. automodule:: kanji_time.utilities.xml
   :members:
   :undoc-members:
   :member-order: bysource
   :show-inheritance:
