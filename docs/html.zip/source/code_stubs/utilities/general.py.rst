.. _kanji_time-utilities-general-py:

====================
utilities/general.py
====================

.. automodule:: kanji_time.utilities.general
   :members:
   :undoc-members:
   :member-order: bysource
   :show-inheritance:
