.. _kanji_time-utilities-_init_-py:

=====================
utilities/__init__.py
=====================

.. automodule:: kanji_time.utilities.__init__
   :members:
   :undoc-members:
   :member-order: bysource
   :show-inheritance:
