.. _kanji_time-utilities-singleton-py:

======================
utilities/singleton.py
======================

.. automodule:: kanji_time.utilities.singleton
   :members:
   :undoc-members:
   :member-order: bysource
   :show-inheritance:
