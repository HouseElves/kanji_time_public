Command Line Interface and Dispatch
===================================

kanji_time_cli.py
-----------------

.. automodule:: kanji_time.kanji_time_cli
   :members:
   :undoc-members:
   :member-order: bysource
   :show-inheritance: