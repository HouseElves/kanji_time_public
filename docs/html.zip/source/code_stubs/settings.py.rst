Global Settings for Kanji Time
==============================

A placeholder for future expansion.

settings.py
-----------

.. automodule:: kanji_time.settings
   :members:
   :undoc-members:
   :member-order: bysource
   :show-inheritance: