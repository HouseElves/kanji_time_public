Program Entry Point
===================

__main__.py
-----------

.. automodule:: kanji_time.__main__
   :members:
   :undoc-members:
   :member-order: bysource
   :show-inheritance: