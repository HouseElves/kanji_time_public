======================
ChatGPT Generated Code
======================

.. toctree::
    :maxdepth: 2

    kanji_time_gpt
