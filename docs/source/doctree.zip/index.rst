Kanji Time
==========

Kanji Time is a small project created by Andrew Milton to help with his study of Japanese language.
The goal is to make printable exercise sheets containing stroke diagrams and ruled practice areas for any kanji character.
Since context is vital to learning kanji, Kanji Time also produces consistently formatted data sheets that contain readings, radical
information, and definitions for kanji characters.

The kanji practice sheets and data sheets work hand-in-hand to cement brush strokes, interpretations, and readings for kanji into long-term
memory.

Kanji Time is in part inspired by the fabulous website `jisho.org <https://jisho.org/>`_ and leverages some of the same trusted data
sources.

The two PDF outputs that Kanji Timne currently produces are just the beginning.
Kanji Time incorporates a flexible drop-in report architecture and simple reusable layout rules that easily allow for future expansion to
new exercise sheets such as:

    - exploring small groups of compound kanji words connected through a common theme (such as a common stroke group, prefix/suffix, reading
      or anything else),
    - reviewing different conjugations and declensions, or,
    - practicing hiragana or katakana penmanship.
  
The possibilities are endless - extensibility and growth are baked in as core design principals.

.. note:: These documentation pages are built from hand-crafted `reStructuredText <https://docutils.sourceforge.io/rst.html>`_
          supplemented with

            - Python code comments extracted via Sphinx with
              `autodoc <https://www.sphinx-doc.org/en/master/usage/extensions/autodoc.html#module-sphinx.ext.autodoc>`_,
            - inline `Mermaid <https://mermaid.js.org/>`_ UML diagrams-as-code rendered using
              `sphinxcontrib-mermaid <https://github.com/mgaitan/sphinxcontrib-mermaid>`_, 
            - todo lists coallated with `todo <https://www.sphinx-doc.org/en/master/usage/extensions/todo.html#directive-todo>`_, and,
            - lots of TLC from the author, Andrew Milton.

   All inline code documentation for public classes and modules is linked in the table of contents, below.
   All diagrams and sequence flows referenced are available in the design section.

Figures
-------

.. toctree::
   :maxdepth: 2

   figures

User Guide
----------

.. toctree::
   :maxdepth: 2

   usage
   cli_entry


Kanji Time Structure
--------------------

The high-level components of Kanji Time are as in the below block diagram.

.. mermaid::

   ---
   config:
     layout: dagre
   ---
   graph LR
     CLI["Command-line Interface"]
     
     DataAggregator["External Data"]

     ReportDispatcher["Report Dispatch"]
     Geometry["Page Geometry"]
     PageLayout["Page Layout Frames"]
     Atomic["Simple (Atomic) Content"]
     Container["Multi-element Frames"]
     Strategies["Page Layout Strategies"]
     Controller["Pagination Loop"]
     
     RenderingTechnology["ReportLab PDF Generator"]
     
     KanjiVG["KanjiVG SVG Data"]
     KanjiDict2["KANJIDIC2 XML"]
     JMdict["JMdict-e XML"]
     Radicals["Unicode Radical DB"]

     CLI --> DataAggregator
     CLI --> ReportDispatcher
     CLI --> RenderingTechnology

     DataAggregator --> KanjiVG
     DataAggregator --> KanjiDict2
     DataAggregator --> JMdict
     DataAggregator --> Radicals

     ReportDispatcher --> Geometry
     ReportDispatcher --> PageLayout
     ReportDispatcher --> Controller

     PageLayout --> Atomic
     PageLayout --> Container
     PageLayout --> Strategies


Design Details
--------------

.. toctree::
   :maxdepth: 2

   design/index
   reports/index
   data/index
   geometry/index
   frames/index

Auxiliary Helpers
-----------------

.. toctree::
   :maxdepth: 2

   misc_helpers/index


Next Steps: Roadmap
-------------------

.. toctree::
   :maxdepth: 2

   roadmap
   dev_notes/index


Credits and Licensing
=====================

Andrew Milton would like to thank his noble simulated intelligence / synthetic code comptency assistant, Smarty Pants, for
baseline code contributions to this project.
Mr. Pants manifests as a ChatGPT LLM -- sometimes 4o, sometimes o1 -- runnning on the author's OpenAI Plus account.

Mr. Pants generated starting code for different modules and tasks as found here.

.. toctree::
   :maxdepth: 1

   gpt_links

Data
----

Kanji Time is built on the shoulders of giants. It incorporates and redistributes the following open data sources:

- **KANJIDIC2** and **JMdict-e**:
  Provided by the *Electronic Dictionary Research and Development Group (EDRDG)*, originally developed by Jim Breen.
  Licensed under `Creative Commons Attribution-ShareAlike 4.0 International <https://creativecommons.org/licenses/by-sa/4.0/>`_.

- **KanjiVG Stroke Diagrams**:
  Copyright © 2009-2024 *Ulrich Apel*. Distributed under the
  `Creative Commons Attribution-ShareAlike 3.0 Unported License <https://creativecommons.org/licenses/by-sa/3.0/>`_.
  SVG files obtained from https://kanjivg.tagaini.net/.

- **Unicode Radical Data**:
  Derived from the official Unicode UCD file `CJKRadicals.txt`.
  Copyright © 1991-2024 *Unicode, Inc.*
  Licensed under the `Unicode License Version 3 <https://www.unicode.org/license.txt>`_.

All source data is redistributed **unmodified** under the terms of their respective licenses. Kanji Time’s source code and rendering logic are copyright © 2024-2025 by Andrew Milton (House Elves).

