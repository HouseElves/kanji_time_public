====================================
radical_summary.py Development Notes
====================================

.. |rarr| unicode:: U+2192
   :ltrim:

.. role:: python(code)
   :language: python

Security
--------

Performance
-----------

Thread Safety (for a multithreaded future)
------------------------------------------


New Features
------------

Features to add in future iterations.

<feature>
~~~~~~~~~

    -
    -


Code Review/Adjustments
-----------------------

    - Factor: convert `RadicalSummary` to be a vanilla horizontally stretchy vertical stack with a minimum size to fit the radical's SVG drawing.
      I don't need to have a customized layout.
