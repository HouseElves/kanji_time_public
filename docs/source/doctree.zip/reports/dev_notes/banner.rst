===========================
banner.py Development Notes
===========================

.. |rarr| unicode:: U+2192
   :ltrim:

.. role:: python(code)
   :language: python

Security
--------

Performance
-----------

Thread Safety (for a multithreaded future)
------------------------------------------


New Features
------------

Features to add in future iterations.

<feature>
~~~~~~~~~

    -
    -


Code Review/Adjustments
-----------------------

    -
