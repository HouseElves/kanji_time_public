Todo List
---------

.. admonition:: TODO

    - The text and drawing frames draw heavily on their ReportLab counterparts.
      I think I need to settle on defined set of properties for a content frame and make an adapter set from Technology <?>
      to my model. (In this case, <?> is clearly ReportLab).
      Notably, I need "space/coordinate system" properties that map into the technology-specific representations.

    - Requested size parameters will make a lot more sense when I formalized a constraint model on distances -
      "exactly 2in" or "at most 50% of parent" or "at least 120pt", etc.

    - Whitespace allocation strategies.  Couple with "accepts whitespace N/S/E/W" flag properties on a content frame.
