======================================
Helpers for Python's `logging` Library
======================================

utilities/general.py

.. automodule:: utilities.general
     :members: log

