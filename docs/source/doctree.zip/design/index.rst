Design at 20,000 Feet
=====================

This section introduces the key structural design patterns used throughout Kanji Time. The system follows a compositional layout model inspired by page-based rendering engines and document frameworks, with each element responsible for measuring, laying out, and rendering itself or its children.

----

ContentFrame Protocol
---------------------

The foundation of layout in Kanji Time is the `ContentFrame` protocol.

All components that can be placed on a page — such as text boxes, glyphs, diagrams, or containers — conform to this protocol.

A `ContentFrame` is responsible for three key phases:

1. **Measurement** - Evaluate the space requirements for a given render target.
2. **Layout** - Adjust child positions relative to a bounding region.
3. **Rendering** - Draw itself to the output surface (typically PDF).

This protocol allows for arbitrary nesting and precise control over alignment, overflow handling, and visual structure.

.. toctree::
   :maxdepth: 1

   design_concepts
   content_frame
   review

----

Coming Soon
-----------

- Page layout strategies
- Container design and flow control
- Composition techniques for multi-page documents
