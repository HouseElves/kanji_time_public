=======================
General Design Concepts
=======================

.. include:: ../../../reports/conceptual.rst
   :start-line: 1

