===================================
Using the KanjiTime CLI: kanji_time
===================================

The `kanji_time.py` module serves as the command-line entry point for generating Kanji Time report PDFs.

It supports multiple report types and can process one or more kanji characters in a single invocation.

.. code-block:: bash

    python kanji_time.py 鳥 馬 魔 --report=practice_sheet
    python kanji_time.py 鳥 --report=kanji_summary

----

Command-Line Options
---------------------

.. code-block:: text

    --report=REPORT, -r REPORT
        Run the specified report. Can be used multiple times.

    --output-dir=DIR, -o DIR
        Directory where output PDF files will be saved. Defaults to the current directory.

    --help-report=REPORT
        Show help text for a specific report, including its glyph-specific behavior.

    kanji
        One or more kanji glyphs to generate output for.

----

Available Reports
------------------

These are the currently registered report aliases and their backing modules:

.. list-table:: Report Registry
   :header-rows: 1

   * - Report Alias
     - Module
   * - ``kanji_summary``
     - ``reports.kanji_summary.report``
   * - ``practice_sheet``
     - ``reports.practice_sheet.report``

Each report must define a `Report` class that implements both the `PageController` and `RenderingFrame` protocols.

----

Execution Flow
--------------

The CLI resolves the requested report by name, gathers data, and enters a page-rendering loop.

.. mermaid::

    sequenceDiagram
        participant CLI as CLI (kanji_time.py)
        participant R as Report
        participant D as Report.Data
        participant PDF as DisplaySurface

        CLI->>R: gather_report_data()
        R->>D: build data object
        CLI->>R: instantiate Report
        loop per page
            CLI->>R: begin_page(n)
            R->>PDF: draw()
            PDF->>PDF: showPage()
        end

----

Exit Codes
----------

.. list-table::
   :header-rows: 1

   * - Code
     - Meaning
   * - ``0``
     - Success
   * - ``1``
     - Failure during help or report module load
   * - ``2``
     - Failure initializing output directory

----

TODOs
-----

.. todo::

    - Migrate rendering logic in `kanji_time.py` into a reusable backend layer.
    - Sync `readme.rst` with this page for a unified narrative on report flow and controller design.
    - Automate extraction of TODOs from inline docstrings and RST comments.

----

References
----------

- :doc:`design/design_concepts`
- :doc:`reports/info_sheet`
- :doc:`reports/practice_sheet`
