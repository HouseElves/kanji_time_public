Geometric Foundations
=====================

This section defines the coordinate system, measurement types, and layout geometry primitives used by all rendering logic in Kanji Time.

Layout in Kanji Time operates in a unit-aware 2D coordinate space, using value types to express physical dimensions, screen-relative
distances, and nested layout regions.

All elements are grounded in a shared system of immutable types:

  - `Distance` - scalar lengths with precise units and soft constraint logic
  - `Pos` - 2D points used for frame origins and anchor positions
  - `Extent` - dimensions (width, height) used for sizing and layout negotiation
  - `Region` - rectangular areas used to scope layout frames
  - `AnchorPoint` - symbolic compass-style alignment hints

These types support arithmetic, layout rules, and diagnostics.
They are passed between `ContentFrame` objects during layout and render phases and provide the backbone for all geometry-aware layout
strategies.

.. automodule:: visual.layout.region

Details
-------

.. toctree::
   :maxdepth: 1

   distance
   pos
   extent
   region


