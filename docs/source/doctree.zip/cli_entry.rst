The Command Line Interface
==========================

Python entry point: `kanji_time.py`

This module provides the CLI interface for executing report generation tasks in Kanji Time.
It includes a dynamic report loader, a generic runner function, and integration points for expanding the report registry.

.. role:: python(code)
   :language: python

Code Module
-----------

.. automodule:: kanji_time

.. _report_runner:

Report Execution
----------------

The CLI defines a general-purpose report runner for dispatching reports by alias or module name.

.. autofunction:: kanji_time.execute_report

Kanji Time discovers and loads reports dynamically using a safe import strategy that supports future expansion of the report catalog.

.. autofunction:: kanji_time.load_report_module


.. [GoF] Erich Gamma, Richard Helm, Ralph Johnson, and John Vlissides.
   *Design Patterns: Elements of Reusable Object-Oriented Software*.
   Addison-Wesley, 1994.
